PRAGMA foreign_keys = ON;

-- Users & roles
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  phone TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT CHECK(role IN ('super_admin','manager','staff')) NOT NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

-- Vouchers
CREATE TABLE IF NOT EXISTS vouchers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  voucher_number TEXT UNIQUE NOT NULL,
  customer_name TEXT NOT NULL,
  customer_phone TEXT NOT NULL,
  department TEXT,
  amount_cents INTEGER NOT NULL,
  payment_method TEXT CHECK(payment_method IN ('cash','card')) NOT NULL,
  status TEXT CHECK(status IN ('pending','paid')) NOT NULL DEFAULT 'pending',
  created_by INTEGER NOT NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(created_by) REFERENCES users(id)
);

-- Payments
CREATE TABLE IF NOT EXISTS payments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  voucher_id INTEGER NOT NULL,
  amount_cents INTEGER NOT NULL,
  method TEXT CHECK(method IN ('cash','card')) NOT NULL,
  paid_by INTEGER NOT NULL, -- user id
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(voucher_id) REFERENCES vouchers(id) ON DELETE CASCADE,
  FOREIGN KEY(paid_by) REFERENCES users(id)
);

-- Expenses
CREATE TABLE IF NOT EXISTS expenses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  description TEXT,
  amount_cents INTEGER NOT NULL,
  expense_date TEXT NOT NULL,
  created_by INTEGER NOT NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(created_by) REFERENCES users(id)
);

-- Collections (per staff: how much cash they collected in a period or entry-based logs)
CREATE TABLE IF NOT EXISTS collections (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  staff_id INTEGER NOT NULL,
  amount_cents INTEGER NOT NULL,
  note TEXT,
  collected_at TEXT NOT NULL,
  created_by INTEGER NOT NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(staff_id) REFERENCES users(id),
  FOREIGN KEY(created_by) REFERENCES users(id)
);

-- Simple audit log (optional, for edits/deletes - minimal for MVP)
CREATE TABLE IF NOT EXISTS audit_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  action TEXT NOT NULL,
  entity TEXT NOT NULL,
  entity_id INTEGER,
  meta TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id)
);
