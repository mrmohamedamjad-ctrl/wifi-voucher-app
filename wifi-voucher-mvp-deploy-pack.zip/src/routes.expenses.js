import express from 'express';
import { db } from '../db.js';
import { authRequired, requireRole } from '../auth.js';
import { cents } from '../utils.js';

const router = express.Router();
router.use(authRequired);

// list expenses with date range
router.get('/', (req,res)=>{
  const { start, end } = req.query;
  let sql = `SELECT e.*, u.name as created_by_name FROM expenses e JOIN users u ON u.id = e.created_by WHERE 1=1`;
  const params = [];
  if(start){ sql += ' AND date(e.expense_date) >= date(?)'; params.push(start); }
  if(end){ sql += ' AND date(e.expense_date) <= date(?)'; params.push(end); }
  sql += ' ORDER BY e.expense_date DESC';
  res.json(db.prepare(sql).all(...params));
});

// create (manager or super)
router.post('/', requireRole('super_admin','manager'), (req,res)=>{
  const { title, description, amount_cents, expense_date } = req.body || {};
  if(!title || !amount_cents || !expense_date) return res.status(400).json({error:'missing required fields'});
  const info = db.prepare('INSERT INTO expenses (title, description, amount_cents, expense_date, created_by) VALUES (?,?,?,?,?)')
    .run(title, description||null, cents(amount_cents), expense_date, req.user.id);
  res.status(201).json(db.prepare('SELECT * FROM expenses WHERE id = ?').get(info.lastInsertRowid));
});

// edit/delete only super admin
router.put('/:id', requireRole('super_admin'), (req,res)=>{
  const id = Number(req.params.id);
  const e = db.prepare('SELECT * FROM expenses WHERE id = ?').get(id);
  if(!e) return res.status(404).json({error:'Not found'});
  const patch = {
    title: req.body.title ?? e.title,
    description: req.body.description ?? e.description,
    amount_cents: req.body.amount_cents != null ? cents(req.body.amount_cents) : e.amount_cents,
    expense_date: req.body.expense_date ?? e.expense_date
  };
  db.prepare('UPDATE expenses SET title=?, description=?, amount_cents=?, expense_date=? WHERE id=?')
    .run(patch.title, patch.description, patch.amount_cents, patch.expense_date, id);
  res.json(db.prepare('SELECT * FROM expenses WHERE id = ?').get(id));
});

router.delete('/:id', requireRole('super_admin'), (req,res)=>{
  const id = Number(req.params.id);
  const info = db.prepare('DELETE FROM expenses WHERE id = ?').run(id);
  res.json({deleted: info.changes});
});

export default router;
