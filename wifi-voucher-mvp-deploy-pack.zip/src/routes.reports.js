import express from 'express';
import { db } from '../db.js';
import { authRequired } from '../auth.js';

const router = express.Router();
router.use(authRequired);

// day-end summary for a date (or range)
router.get('/day-end', (req,res)=>{
  const { start, end } = req.query;
  const s = start || new Date().toISOString().slice(0,10);
  const e = end || s;

  const income = db.prepare(`SELECT IFNULL(SUM(amount_cents),0) as sum FROM payments 
    WHERE date(created_at) BETWEEN date(?) AND date(?)`).get(s,e).sum;

  const expenses = db.prepare(`SELECT IFNULL(SUM(amount_cents),0) as sum FROM expenses 
    WHERE date(expense_date) BETWEEN date(?) AND date(?)`).get(s,e).sum;

  const collections = db.prepare(`SELECT IFNULL(SUM(amount_cents),0) as sum FROM collections 
    WHERE date(collected_at) BETWEEN date(?) AND date(?)`).get(s,e).sum;

  const profit = income - expenses;

  res.json({ start:s, end:e, totals_cents: { income, expenses, collections, profit } });
});

export default router;
