export function cents(n){ return Math.round(Number(n) || 0); }
export function nowISO(){ return new Date().toISOString(); }
