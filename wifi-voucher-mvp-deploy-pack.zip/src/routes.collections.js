import express from 'express';
import { db } from '../db.js';
import { authRequired, requireRole } from '../auth.js';
import { cents } from '../utils.js';

const router = express.Router();
router.use(authRequired);

// list by staff and date
router.get('/', (req,res)=>{
  const { staff_id, start, end } = req.query;
  let sql = `SELECT c.*, s.name as staff_name, u.name as created_by_name FROM collections c 
             JOIN users s ON s.id = c.staff_id 
             JOIN users u ON u.id = c.created_by WHERE 1=1`;
  const params = [];
  if(staff_id){ sql += ' AND c.staff_id = ?'; params.push(staff_id); }
  if(start){ sql += ' AND date(c.collected_at) >= date(?)'; params.push(start); }
  if(end){ sql += ' AND date(c.collected_at) <= date(?)'; params.push(end); }
  sql += ' ORDER BY c.collected_at DESC';
  let rows = db.prepare(sql).all(...params);
  // If role is staff, restrict to own records
  if(req.user.role === 'staff'){
    rows = rows.filter(r=> r.staff_id === req.user.id);
  }
  const total = rows.reduce((acc,r)=> acc + r.amount_cents, 0);
  res.json({ items: rows, total_cents: total });
});

// add collection (manager only per spec; allow staff via manager's UI? We'll allow manager and staff add own)
router.post('/', requireRole('manager','super_admin','staff'), (req,res)=>{
  const { staff_id, amount_cents, note, collected_at } = req.body || {};
  let sId = staff_id || req.user.id;
  if(req.user.role==='staff' && staff_id && Number(staff_id)!==req.user.id){
    return res.status(403).json({error:'Staff can only create their own collection entries'});
  }
  if(!amount_cents || !collected_at) return res.status(400).json({error:'missing required fields'});
  const info = db.prepare('INSERT INTO collections (staff_id, amount_cents, note, collected_at, created_by) VALUES (?,?,?,?,?)')
    .run(sId, cents(amount_cents), note||null, collected_at, req.user.id);
  res.status(201).json(db.prepare('SELECT * FROM collections WHERE id = ?').get(info.lastInsertRowid));
});

export default router;
