import express from 'express';
import { db } from '../db.js';
import { authRequired } from '../auth.js';
import { cents } from '../utils.js';

const router = express.Router();
router.use(authRequired);

// list payments (optional filters)
router.get('/', (req,res)=>{
  const { voucher_id } = req.query;
  let sql = `SELECT p.*, u.name as paid_by_name FROM payments p JOIN users u ON u.id = p.paid_by WHERE 1=1`;
  const params = [];
  if(voucher_id){ sql += ' AND p.voucher_id = ?'; params.push(voucher_id); }
  sql += ' ORDER BY p.created_at DESC';
  res.json(db.prepare(sql).all(...params));
});

// create payment
router.post('/', (req,res)=>{
  const { voucher_id, amount_cents, method } = req.body || {};
  if(!voucher_id || !amount_cents || !method) return res.status(400).json({error:'missing required fields'});
  // add payment
  const info = db.prepare('INSERT INTO payments (voucher_id, amount_cents, method, paid_by) VALUES (?,?,?,?)')
    .run(voucher_id, cents(amount_cents), method, req.user.id);
  // update voucher status if fully paid (MVP: assumes single payment equals voucher amount)
  const v = db.prepare('SELECT * FROM vouchers WHERE id = ?').get(voucher_id);
  if(v && v.amount_cents <= cents(amount_cents)){
    db.prepare('UPDATE vouchers SET status = ? WHERE id = ?').run('paid', voucher_id);
  }
  res.status(201).json(db.prepare('SELECT * FROM payments WHERE id = ?').get(info.lastInsertRowid));
});

export default router;
