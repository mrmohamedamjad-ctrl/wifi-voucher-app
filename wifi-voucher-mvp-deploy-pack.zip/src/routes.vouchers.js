import express from 'express';
import { db } from '../db.js';
import { authRequired, requireRole } from '../auth.js';
import { cents } from '../utils.js';

const router = express.Router();
router.use(authRequired);

// list with filters (pending by default)
router.get('/', (req,res)=>{
  const { status, method, q } = req.query;
  let sql = `SELECT v.*, u.name as created_by_name FROM vouchers v JOIN users u ON u.id = v.created_by WHERE 1=1`;
  const params = [];
  if(status){ sql += ' AND v.status = ?'; params.push(status); }
  if(method){ sql += ' AND v.payment_method = ?'; params.push(method); }
  if(q){
    sql += ' AND (v.voucher_number LIKE ? OR v.customer_name LIKE ? OR v.customer_phone LIKE ? OR v.department LIKE ?)';
    params.push(`%${q}%`,`%${q}%`,`%${q}%`,`%${q}%`);
  }
  sql += ' ORDER BY v.created_at DESC';
  const rows = db.prepare(sql).all(...params);
  res.json(rows);
});

// create
router.post('/', requireRole('super_admin','manager'), (req,res)=>{
  const { voucher_number, customer_name, customer_phone, department, amount_cents, payment_method } = req.body || {};
  if(!voucher_number || !customer_name || !customer_phone || !amount_cents || !payment_method){
    return res.status(400).json({error:'missing required fields'});
  }
  const info = db.prepare(`INSERT INTO vouchers (voucher_number, customer_name, customer_phone, department, amount_cents, payment_method, status, created_by) 
     VALUES (?,?,?,?,?,?, 'pending', ?)`)
     .run(voucher_number, customer_name, customer_phone, department||null, cents(amount_cents), payment_method, req.user.id);
  const row = db.prepare('SELECT * FROM vouchers WHERE id = ?').get(info.lastInsertRowid);
  res.status(201).json(row);
});

// edit (Super Admin only)
router.put('/:id', requireRole('super_admin'), (req,res)=>{
  const id = Number(req.params.id);
  const v = db.prepare('SELECT * FROM vouchers WHERE id = ?').get(id);
  if(!v) return res.status(404).json({error:'Not found'});
  const patch = {
    customer_name: req.body.customer_name ?? v.customer_name,
    customer_phone: req.body.customer_phone ?? v.customer_phone,
    department: req.body.department ?? v.department,
    amount_cents: req.body.amount_cents != null ? cents(req.body.amount_cents) : v.amount_cents,
    payment_method: req.body.payment_method ?? v.payment_method,
    status: req.body.status ?? v.status
  };
  db.prepare(`UPDATE vouchers SET customer_name=?, customer_phone=?, department=?, amount_cents=?, payment_method=?, status=? WHERE id=?`)
    .run(patch.customer_name, patch.customer_phone, patch.department, patch.amount_cents, patch.payment_method, patch.status, id);
  const row = db.prepare('SELECT * FROM vouchers WHERE id = ?').get(id);
  res.json(row);
});

// delete (Super Admin only)
router.delete('/:id', requireRole('super_admin'), (req,res)=>{
  const id = Number(req.params.id);
  const info = db.prepare('DELETE FROM vouchers WHERE id = ?').run(id);
  res.json({deleted: info.changes});
});

export default router;
