import Database from 'better-sqlite3';
import 'dotenv/config';

export const db = new Database(process.env.DB_FILE, { verbose: null });
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
