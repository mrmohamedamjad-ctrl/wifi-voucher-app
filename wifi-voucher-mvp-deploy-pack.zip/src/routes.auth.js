import express from 'express';
import crypto from 'crypto';
import jwt from 'jsonwebtoken';
import { db } from '../db.js';

const router = express.Router();

function hash(pw){ return crypto.createHash('sha256').update(pw).digest('hex'); }

router.post('/login', (req,res)=>{
  const { phone, password } = req.body || {};
  if(!phone || !password) return res.status(400).json({error:'phone and password required'});
  const user = db.prepare('SELECT * FROM users WHERE phone = ?').get(phone);
  if(!user) return res.status(401).json({error:'Invalid credentials'});
  if(user.password_hash !== hash(password)) return res.status(401).json({error:'Invalid credentials'});
  const token = jwt.sign({ id:user.id, name:user.name, role:user.role, phone:user.phone }, process.env.JWT_SECRET, { expiresIn:'8h' });
  res.json({ token, user: { id:user.id, name:user.name, role:user.role, phone:user.phone } });
});

export default router;
