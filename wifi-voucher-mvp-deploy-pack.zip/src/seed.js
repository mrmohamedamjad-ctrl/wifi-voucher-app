import 'dotenv/config';
import Database from 'better-sqlite3';
import fs from 'fs';
import crypto from 'crypto';

const db = new Database(process.env.DB_FILE, { verbose: null });

const schema = fs.readFileSync('./src/schema.sql', 'utf8');
db.exec(schema);

function hash(pw){ return crypto.createHash('sha256').update(pw).digest('hex'); }

// Users
const users = [
  {name:'Owner', phone:'0700000000', password:'owner123', role:'super_admin'},
  {name:'Mara', phone:'0700000001', password:'manager123', role:'manager'},
  {name:'Sam', phone:'0700000002', password:'staff123', role:'staff'}
];
const insUser = db.prepare('INSERT OR IGNORE INTO users (name, phone, password_hash, role) VALUES (?,?,?,?)');
for (const u of users){
  insUser.run(u.name, u.phone, hash(u.password), u.role);
}

// Vouchers
const insVoucher = db.prepare(`INSERT OR IGNORE INTO vouchers 
  (voucher_number, customer_name, customer_phone, department, amount_cents, payment_method, status, created_by) 
  VALUES (?,?,?,?,?,?,?,?)`);
insVoucher.run('V-1001','Alice','0711111111','Sales', 5000, 'cash','pending', 2);
insVoucher.run('V-1002','Bob','0722222222','IT',    12000,'card','pending', 2);

// Expenses
const insExp = db.prepare(`INSERT INTO expenses (title, description, amount_cents, expense_date, created_by) VALUES (?,?,?,?,?)`);
insExp.run('Router purchase','New router', 30000,'2025-08-01',1);
insExp.run('ISP bill','Monthly subscription', 150000,'2025-08-05',1);

// Collections
const insCol = db.prepare(`INSERT INTO collections (staff_id, amount_cents, note, collected_at, created_by) VALUES (?,?,?,?,?)`);
insCol.run(3, 5000, 'Morning shift','2025-08-10', 2);

console.log('Database seeded:', process.env.DB_FILE);
db.close();
